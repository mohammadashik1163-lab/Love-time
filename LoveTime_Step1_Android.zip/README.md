# Love Time — Android Step 1
A starter Android Studio project for the Love Time app.

Included:
- Love Time branding
- Bangla / English toggle
- Home screen
- Online user cards
- Coin balance UI
- Call button UI (placeholder for Step 2)

Open the folder in Android Studio and let Gradle sync.
Then run on an Android device/emulator.

Step 2 will require a real-time video/audio calling backend/SDK.
