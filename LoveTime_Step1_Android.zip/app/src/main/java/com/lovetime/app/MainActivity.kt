package com.lovetime.app

import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var bangla = false
    private lateinit var title: TextView
    private lateinit var balance: TextView
    private lateinit var subtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            setBackgroundColor(Color.WHITE)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        title = TextView(this).apply {
            text = "Love Time ❤️"
            textSize = 28f
            setTextColor(Color.rgb(210, 30, 80))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        top.addView(title, LinearLayout.LayoutParams(0, 60, 1f))

        val lang = Button(this).apply {
            text = "বাংলা / EN"
            setOnClickListener { bangla = !bangla; updateText() }
        }
        top.addView(lang, LinearLayout.LayoutParams(120, 55))
        root.addView(top)

        balance = TextView(this).apply {
            text = "💎 0 Coins"
            textSize = 17f
            setPadding(0, 18, 0, 18)
        }
        root.addView(balance)

        subtitle = TextView(this).apply {
            text = "Meet people and connect"
            textSize = 21f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(subtitle)

        val names = listOf("Maya", "Sadia", "Nusrat", "Jannat")
        names.forEach { name ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(18, 18, 12, 18)
                setBackgroundColor(Color.rgb(248, 248, 248))
            }
            val info = TextView(this).apply {
                text = "🟢 $name\n${if (bangla) "অনলাইনে আছেন" else "Online now"}"
                textSize = 17f
            }
            card.addView(info, LinearLayout.LayoutParams(0, 90, 1f))
            val call = Button(this).apply {
                text = "📞 ${if (bangla) "কল" else "Call"}"
                setOnClickListener { Toast.makeText(this@MainActivity,
                    if (bangla) "ভিডিও কল শিগগিরই আসছে" else "Video calling is coming in Step 2",
                    Toast.LENGTH_SHORT).show() }
            }
            card.addView(call)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 105)
            lp.setMargins(0, 12, 0, 0)
            root.addView(card, lp)
        }

        val profile = Button(this).apply {
            text = "👤 ${if (bangla) "আমার প্রোফাইল" else "My Profile"}"
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    if (bangla) "প্রোফাইল স্ক্রিন Step 1-এ প্রস্তুত" else "Profile screen is ready for Step 1",
                    Toast.LENGTH_SHORT).show()
            }
        }
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 60)
        plp.setMargins(0, 20, 0, 0)
        root.addView(profile, plp)

        setContentView(root)
    }

    private fun updateText() {
        subtitle.text = if (bangla) "মানুষের সাথে পরিচিত হন ও যোগাযোগ করুন" else "Meet people and connect"
        balance.text = if (bangla) "💎 ০ কয়েন" else "💎 0 Coins"
        showHome()
    }
}
